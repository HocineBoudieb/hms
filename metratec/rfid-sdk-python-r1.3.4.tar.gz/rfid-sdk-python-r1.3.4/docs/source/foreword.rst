Foreword
========

With this SDK you can control the Metratec RFID readers within Python.
The SDK uses the asyncio library and is written in Python 3.10.
It supports both HF and UHF readers, like the QuasarMX, QuasarLR,
PulsarMX and PulsarLR as well as all DeskID products and OEM modules.