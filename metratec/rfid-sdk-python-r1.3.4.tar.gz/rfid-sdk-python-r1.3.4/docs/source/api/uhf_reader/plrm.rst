.. currentmodule:: metratec_rfid

.. _plrm:

PLRM UHF RFID Reader
========================

TODO image
  
TODO description

.. autoclass:: metratec_rfid.Plrm
    :members:
    :inherited-members:
    :special-members: __init__
