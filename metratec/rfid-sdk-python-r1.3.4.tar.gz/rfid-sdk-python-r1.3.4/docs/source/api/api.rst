.. _api:

API
###

This part of the documentation covers all the core classes.

.. toctree::
   :maxdepth: 2

   hf_reader/hf_reader
   uhf_reader/uhf_reader
   transponder
   utils
   connection
