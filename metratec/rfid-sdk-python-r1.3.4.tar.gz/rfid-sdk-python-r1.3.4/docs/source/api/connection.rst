.. currentmodule:: metratec_rfid

Connection
==========

Serial Connection
-----------------

.. autoclass:: metratec_rfid.connection.serial_connection.SerialConnection
    :special-members: __init__

Socket Connection
-----------------

.. autoclass:: metratec_rfid.connection.socket_connection.SocketConnection
    :special-members: __init__