.. currentmodule:: metratec_rfid

Utilities
==========

Automatic Reader Detection
--------------------------

.. autofunction:: metratec_rfid.detect_readers
