.. _hf_reader:

HF Reader
##########

This part of the documentation covers all the core classes.

.. toctree::
   :maxdepth: 1

   deskid_iso
   deskid_nfc
   quasar_lr
   quasar_mx
   qr_nfc
